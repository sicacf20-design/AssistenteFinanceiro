@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle nao encontrado. No GitHub, use o workflow em .github\workflows\build-apk.yml
  exit /b 1
)
gradle --no-daemon assembleDebug
if errorlevel 1 exit /b 1
echo APK gerado em: app\build\outputs\apk\debug\app-debug.apk
