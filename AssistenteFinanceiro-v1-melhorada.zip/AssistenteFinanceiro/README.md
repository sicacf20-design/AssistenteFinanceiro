# Assistente Financeiro v1 — versão melhorada

MVP Android em Java, sem bibliotecas externas obrigatórias.

## Incluído
- Dashboard com saldo, receitas, gastos e dívidas
- Menu inferior: Início, Movimentações, Contas e Dívidas
- Cadastro de receitas e despesas
- Categorias de movimentação
- Cadastro de dívidas
- Dados persistidos localmente com SharedPreferences
- Assistente financeiro básico com orientações baseadas nos lançamentos
- Layout com cards, cores e navegação vertical
- Estrutura preparada para futuras integrações oficiais de Open Finance e Serasa

## Compilação automática
O workflow em `.github/workflows/build-apk.yml` gera o APK de debug como artefato no GitHub Actions.

## Próximas versões
- Contas recorrentes e vencimentos reais
- Gráficos
- Parcelamentos
- Backup/sincronização
- Login
- Open Finance
- Integrações oficiais de dados de dívidas
- Assistente com IA
